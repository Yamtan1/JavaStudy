package ex01;

import java.util.Random;

public class Lotto0313 {

	public static void main(String[] args) {
		// 로또 번호 추출기 1~45번까지에옹
		// 6개의 번호를 얻어내야함. 배열에다가
		// 중복된 값이 나오면 안됨.
		Random rd = new Random();
		int[] lotto = new int[6];
		
		for(int i = 0 ; i < lotto.length ; i++) {
			int num = rd.nextInt(45) + 1;
			lotto[i] = num;
			
			System.out.print(lotto[i] + " ");
		}
	}
}
