import 'dart:io';
import 'dart:math';

void calculate() {
  stdout.writeln('가위, 바위, 보 중 하나를 입력하세요');
  String? userInput = stdin.readLineSync();

  if (userInput == null || userInput.isEmpty) {
    print('입력이 없습니다. 종료합니다.');
    return;
  }
  List<String> choices = ['가위', '바위', '보'];
  String computerChoice = choices[Random().nextInt(3)];

  print('컴퓨터: $computerChoice');
  print('당신 입력 원본: ${userInput}');
  

  if (userInput == computerChoice) {
    print('비겼습니다!');
  } else if (
    (userInput == '가위' && computerChoice == '보') ||
    (userInput == '바위' && computerChoice == '가위') ||
    (userInput == '보' && computerChoice == '바위')
  ) {
    print('당신이 이겼습니다!');
  } else {
    print('컴퓨터가 이겼습니다!');
  }
}