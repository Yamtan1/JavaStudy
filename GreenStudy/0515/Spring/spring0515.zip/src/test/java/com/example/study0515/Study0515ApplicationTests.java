package com.example.study0515;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Study0515ApplicationTests {

	@Test
	void contextLoads() {
	}

}
