package com.example.study0515;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Study0515Application {

	public static void main(String[] args) {
		SpringApplication.run(Study0515Application.class, args);
	}

}
