package com.example.jpaEx01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaEx01Application {

	public static void main(String[] args) {
		SpringApplication.run(JpaEx01Application.class, args);
	}

}
