package com.example.jpaEx02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaEx02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
