package com.example.jpaEx02.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.jpaEx02.memberEntity.MemberEntity;
import com.example.jpaEx02.repository.MemberRepository;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Controller
public class MainController {
	
	@Autowired
	MemberRepository memberRepository;
	
	@GetMapping("/")
	public String root() {
		log.info("root........................");
		return "index";
	}
	@PostMapping("/insert")
	public String insert(MemberEntity member,RedirectAttributes rttr) {
		memberRepository.save(member);
		return "success";
		
	}
	@PostMapping("/delete")
	public String delete(@RequestParam("name")String name) {
		memberRepository.deleteById(name);
		return "success";
	}
	@GetMapping("/list")
	public String list(Model model) {
		log.info("list.............");
		List<MemberEntity> list = memberRepository.findAll();
		model.addAttribute("list", list);
		
		return "list";
	}
}
