package com.example.jpaEx02.memberEntity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "tbl_member3")
@Getter
@Setter
public class MemberEntity {
	@Id
	private String name;
	private String age;
	private String phone;

}
