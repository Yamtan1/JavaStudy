package com.example.jpaEx02.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.jpaEx02.memberEntity.MemberEntity;

public interface MemberRepository extends JpaRepository<MemberEntity, String> {

}
