package com.example.jpa1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityexApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityexApplication.class, args);
	}

}
