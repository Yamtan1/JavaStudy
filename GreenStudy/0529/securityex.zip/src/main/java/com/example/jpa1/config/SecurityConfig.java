package com.example.jpa1.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

//Security 요청이 들어오면 처리할 걸 찾아주는 
@Configuration
@EnableWebSecurity
public class SecurityConfig {
	// 스테레오 어노테이션:controller,service,repository
	// 메서드에 빈을 붙이면 이 메서드의 반환 자료가 Bean으로 등록된다

	@Bean
	SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
		// root경로는 모두에게 개방시켜라 //이거 안하면 아이디+콘솔에 나오는 보안처리된 비밀번호 입력해야 들어가짐
		// anyRequest()를 하면 모두 통과시킴(security에선 사실상 안 쓴다)
		http.authorizeHttpRequests(auth -> auth.
				requestMatchers("/").permitAll()
				.anyRequest().authenticated()
				);
		
		http.formLogin(auth->auth
				.loginPage("/login")
				.loginProcessingUrl("/loginProc")
				.defaultSuccessUrl("/welcome")
				.permitAll()
				);
		//http.formLogin(Customizer.withDefaults());
		//http.httpBasic(Customizer.withDefaults());
		http.csrf(csrf -> csrf.disable());
		http.logout(Customizer.withDefaults());
		
		return http.build();
	}
}
