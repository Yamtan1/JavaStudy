package com.example.jpaboard.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.jpaboard.entity.BoardEntity;
import com.example.jpaboard.repository.BoardRepository;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class BoardController {
			
	@Autowired
	BoardRepository boardrepository;
	
	@GetMapping("/")
	public String root() {
		return "index";
	}
	
	@GetMapping("/list")
	public String list(Model model) {
		List<BoardEntity> list=boardrepository.findAll();
		model.addAttribute("list",list);
		return "list";
	}
	@GetMapping("/detail")
	public String datail(@RequestParam("bno")String bno,Model model) {
		Optional<BoardEntity> result=boardrepository.findById(bno);
		BoardEntity board=result.get();
		model.addAttribute("board",board);
		return "detail";
	}
	@GetMapping("/regist")
	public String registForm() {
		return "regist";
	}
	@PostMapping("/regist")
	public String regist(BoardEntity boardentity) {
		BoardEntity b=boardrepository.save(boardentity);
		return "index";
	}
	@GetMapping("/update")
	public String updateForm() {
		return "update";
	}
	@PostMapping("/update")
	public String update(BoardEntity boardentity) {
		boardrepository.save(boardentity);
		return "redirect:/detail?bno="+boardentity.getBno();
	}
	@GetMapping("/delete")
	public String delete(@RequestParam("bno") String bno) {
		boardrepository.deleteById(bno);
		return "redirect:/list";
	}
}
