package com.example.jpaboard.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.jpaboard.entity.BoardEntity;

public interface BoardRepository extends JpaRepository<BoardEntity,String> {
	
}
