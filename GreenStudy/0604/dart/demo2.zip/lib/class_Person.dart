class Person{
  String _name;
  int _age;

  // 생성자
  Person(String name, int age)
    : _name = name,
     _age = age;
  

  //getter
  String get name => _name;
  int get age => _age;


  //setter
  set name(String name) {_name = name;}
  set age(int age) => _age = age;

  void showInfo(){
    print('name : $_name');
    print('age : $_age');
  }
}

  