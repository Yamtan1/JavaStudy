package com.example.rest01.dto;

import lombok.Data;

@Data
public class MemberDto {
	
	private String name;
	private String email;
	private String organization;
}
