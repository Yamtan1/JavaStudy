package com.example.rest01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Rest01Application {

	public static void main(String[] args) {
		SpringApplication.run(Rest01Application.class, args);
	}

}
