package com.example.rest01.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.rest01.dto.MemberDto;
@Repository
public class MemberRepository {

    // MemberDto 객체들을 저장할 리스트
    private List<MemberDto> list = new ArrayList<>();

    // 생성자
    public MemberRepository() {
        // 회원 정보 생성
        MemberDto member1 = new MemberDto();
        member1.setName("andy");
        member1.setEmail("andy@green.com");
        member1.setOrganization("green");

        MemberDto member2 = new MemberDto();
        member2.setName("ben");
        member2.setEmail("ben@green.com");
        member2.setOrganization("green");

        MemberDto member3 = new MemberDto();
        member3.setName("david");
        member3.setEmail("david@green.com");
        member3.setOrganization("green");

        // 리스트에 추가
        list.add(member1);
        list.add(member2);
        list.add(member3);
    }

    // 리스트 반환 메소드
    public List<MemberDto> getMembers() {
        return list;
    }
    public boolean insertMember(MemberDto member) {
    	boolean result = list.add(member);
    	return result;
    }
}
