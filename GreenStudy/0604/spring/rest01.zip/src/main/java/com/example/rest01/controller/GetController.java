package com.example.rest01.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.rest01.dto.MemberDto;

@RestController
@RequestMapping("/api/v1/get-api")
public class GetController {
	List<MemberDto> list = new ArrayList<>();
	
	//http://localhost:8090/api/v1/get-api/hello
	//Hello World가 반환되도록 구현
	@GetMapping("/hello")
	public String hello() {
		return "Hello World";
	}
	
	//http://localhost:8090/api/v1/get-api/variable1/{variable}
	@GetMapping("/variable1/{variable}")
    public String getVariable(@PathVariable("variable") String variable) {
        return "입력받은 값: " + variable;
    }
	
	//http://localhost:8090/api/v1/get-api/request1?name=value&email=value2&organization=value3
	@GetMapping("/request1")
	public String request1(@RequestParam("name")String name, @RequestParam("email")String email,
						   @RequestParam("organization")String organization) {
		return "name = " + name + ", email = " + email + ", organization = " + organization;
	}
	//http://localhost:8090/api/v1/get-api/request2?key1=value1&key2=value2
	@GetMapping("/request2")
	public Map<String, String> request2(@RequestParam("key1") String key1, @RequestParam("key2") String key2){
		Map<String, String> result = new HashMap<>();
	    result.put("key1", key1);
	    result.put("key2", key2);
	    return result;
	}
	
	//http://localhost:8090/api/v1/get-api/request3?name=value&email=value2&organization=value3
	@GetMapping("/request3")
	public MemberDto request3(MemberDto member) {
		MemberDto m = new MemberDto();
		m.setName(member.getName());
		m.setEmail(member.getEmail());
		m.setOrganization(member.getOrganization());
		return m;
	}
	
	//http://localhost:8090/api/v1/get-api/request4/{name}
	@GetMapping("/request4/{name}")
    public ResponseEntity<MemberDto> getRequest4(@PathVariable("name") String name) {

        List<MemberDto> list = new ArrayList<>();

        MemberDto member1 = new MemberDto();
        member1.setName("Ann");
        member1.setEmail("ann@green.com");
        member1.setOrganization("GREEN");

        MemberDto member2 = new MemberDto();
        member2.setName("Ben");
        member2.setEmail("ben@green.com");
        member2.setOrganization("GREEN");

        MemberDto member3 = new MemberDto();
        member3.setName("Choi");
        member3.setEmail("choi@green.com");
        member3.setOrganization("GREEN");

        list.add(member1);
        list.add(member2);
        list.add(member3);

     // 이름 일치하는 멤버 찾기
        for (MemberDto member : list) {
            if (member.getName().equals(name)) {
                //return ResponseEntity.status(200).body(member); // 200 OK + JSON 응답
            	//return ResponseEntity.status(HttpStatus.OK).body(member); // 200 OK + JSON 응답
                return ResponseEntity.ok(member); // 200 OK + JSON 응답
            }
        }

        // 못 찾았으면 404 응답
        return ResponseEntity.notFound().build();
    }
	
	//http://localhost:8090/api/v1/get-api/request5/{name}
	@GetMapping("/request5/{name}")
    public int getRequest5(@PathVariable("name") String name) {

        List<MemberDto> list = new ArrayList<>();

        MemberDto member1 = new MemberDto();
        member1.setName("Ann");
        member1.setEmail("ann@green.com");
        member1.setOrganization("GREEN");

        MemberDto member2 = new MemberDto();
        member2.setName("Ben");
        member2.setEmail("ben@green.com");
        member2.setOrganization("GREEN");

        MemberDto member3 = new MemberDto();
        member3.setName("Choi");
        member3.setEmail("choi@green.com");
        member3.setOrganization("GREEN");

        list.add(member1);
        list.add(member2);
        list.add(member3);
	     // 이름 일치하는 멤버 찾기
        for (MemberDto member : list) {
            if (member.getName().equals(name)) {
                return 200;
            }
        }

	        // 못 찾았으면 404 응답
        return 404;
    }

	//http://localhost:8090/api/v1/get-api/request6/{name}
	@GetMapping("/request6/{name}")
    public Map<Integer, MemberDto> getRequest6(@PathVariable("name") String name) {
		List<MemberDto> list = new ArrayList<>();
		
        MemberDto member1 = new MemberDto();
        member1.setName("Ann");
        member1.setEmail("ann@green.com");
        member1.setOrganization("GREEN");

        MemberDto member2 = new MemberDto();
        member2.setName("Ben");
        member2.setEmail("ben@green.com");
        member2.setOrganization("GREEN");

        MemberDto member3 = new MemberDto();
        member3.setName("Choi");
        member3.setEmail("choi@green.com");
        member3.setOrganization("GREEN");

        list.add(member1);
        list.add(member2);
        list.add(member3);

     // 이름 일치하는 멤버 찾기
        Map<Integer, MemberDto> result = new HashMap<>();
        boolean flag = false;
        for(MemberDto m : list) {
        	if(m.getName().equals(name)) {
        		result.put(200, m);
        		flag = true;
        		break;
        	}
        }
        if(!flag) {
        	result.put(404, null);
        }
        return result;
	}
}