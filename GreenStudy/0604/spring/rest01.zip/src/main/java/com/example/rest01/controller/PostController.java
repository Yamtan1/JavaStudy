package com.example.rest01.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.rest01.Rest01Application;
import com.example.rest01.dto.MemberDto;
import com.example.rest01.repository.MemberRepository;

@RestController
@RequestMapping("/api/v1/post-api")
public class PostController {
	
	@Autowired
	MemberRepository mr;

    private final Rest01Application rest01Application;

    PostController(Rest01Application rest01Application) {
        this.rest01Application = rest01Application;
    }
	//http://localhost:8090/api/v1/post-api/domain
	@PostMapping("/domain")
	public String postEx() {
		return "Hello Post API";
	}
	
	//http://localhost:8090/api/v1/post-api/member
	@PostMapping("/member")
	public String postMember(@RequestBody MemberDto member) {
		return member.toString();
	}
	
	//http://localhost:8090/api/v1/post-api/member2
	@PostMapping("/member2")
	public String postMember2(@RequestBody Map<String, Object> postData) {
		StringBuilder sb = new StringBuilder();
		
		postData.entrySet().forEach(map -> {
			sb.append(map.getKey() + ":" + map.getValue() + "\n");
		});
		return sb.toString();
	}
	
	//http://localhost:8090/api/v1/post-api/member3
	@PostMapping("/member3")
	public ResponseEntity<MemberDto> postMember3(@RequestBody MemberDto member) {
	       // 1. email null 체크
	       if (member.getEmail() == null) {
	           return ResponseEntity.badRequest().build(); // 400 Bad Request
	       }

	       // 2. 기존 멤버 리스트 선언 및 초기화
	       List<MemberDto> list = mr.getMembers();

	       // 3. 중복 email 검사
	       for (MemberDto m : list) {
	           if (m.getEmail().equalsIgnoreCase(member.getEmail())) {
	               return ResponseEntity.status(HttpStatus.CONFLICT).build(); // 409 Conflict
	           }
	       }

	       // 4. 등록 성공
	       if(mr.insertMember(member)){
	    	   return ResponseEntity.status(HttpStatus.CREATED).body(member); // 201 Created   
	       }
	       return ResponseEntity.unprocessableEntity().build();
	       
	   }

}
