package com.example.rest01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Rest01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
