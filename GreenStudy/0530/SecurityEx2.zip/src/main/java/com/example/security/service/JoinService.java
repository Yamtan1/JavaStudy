package com.example.security.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.security.dto.UserDto;
import com.example.security.entity.User;
import com.example.security.repository.UserRepository;

@Service
public class JoinService {
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
	private UserRepository userRepository;
	
	public User regist(UserDto userDto) {
	    User user = new User();
	    user.setUsername(userDto.getUsername());
	    user.setPassword(bCryptPasswordEncoder.encode(userDto.getPassword()));
	    user.setName(userDto.getName());

	    if (userDto.getUsername().equals("admin")) {
	        user.setRole("ROLE_ADMIN"); // 소문자 오타 수정
	    } else {
	        user.setRole("ROLE_MEMBER");
	    }
	 // 2. 저장
	    return userRepository.save(user);
	}

		
		
	
	
}
