abstract class Animal {
  String name;

  Animal(this.name);

  void makeSound(); // 추상 메서드
  void move();      // 또 다른 추상 메서드
}