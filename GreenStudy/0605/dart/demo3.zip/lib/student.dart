import 'package:demo3/person.dart';
import 'package:intl/intl.dart';

class Student extends Person{
  late int studentId;

  Student(this.studentId, String name, int age,DateTime birth)
    :super.full(name, birth: birth, age: age);

    @override
    void showInfo(){
      var year = DateTime.now().year -age!;
    var birthStr = DateFormat('yyyy/MM/dd').format(birth ?? DateTime(year, 1, 1));
    print('strudentId: $studentId, name: $name, age: $age, birth: $birthStr');
    }
}