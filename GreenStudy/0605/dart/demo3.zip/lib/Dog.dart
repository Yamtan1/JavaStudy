import 'package:demo3/Animal.dart';

class Dog extends Animal {
  Dog(String name) : super(name);

  @override
  void makeSound() {
    print('$name: 멍멍!');
  }

  @override
  void move() {
    print('$name: 네 발로 달린다.');
  }
}