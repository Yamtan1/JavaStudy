import 'package:intl/intl.dart';

class Person {
  String? name;
  int? age;
  DateTime? birth;

  Person();

  Person.create({required this.name, required this.age});

  Person.onlyName({required this.name});

  Person.onlyAge({required this.age});

  Person.full(this.name, {this.age = 20, this.birth});
  //이름 포지션파라미터 나이 생일은 네임드 파라미터 나이는 기본값 20
  

  void showinfo() {
  if (name == null) {
    print('이름 정보가 없습니다.');
    return;
  }

  if (birth == null && age == null) {
    print('나이와 생일 정보가 모두 없습니다.');
    return;
  }

  DateTime estimatedBirth =
      birth ?? DateTime(DateTime.now().year - age!, 1, 1);

  String formattedBirth = DateFormat('yyyy/MM/dd').format(estimatedBirth);

  print('name : $name , age : ${age ?? DateTime.now().year - birth!.year} , birth : $formattedBirth');
}
}