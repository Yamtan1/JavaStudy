package com.example.rest02.utill;

import com.example.rest02.dto.BoardDto;
import com.example.rest02.entity.BoardEntity;

public class BoardMapper {

    // Dto → Entity
    public static BoardEntity toEntity(BoardDto dto) {
        if (dto == null) return null;

        BoardEntity entity = new BoardEntity();
        entity.setBno(dto.getBno());
        entity.setTitle(dto.getTitle());
        entity.setContent(dto.getContent());
        entity.setWriter(dto.getWriter());
        
        return entity;
    }

    // Entity → Dto
    public static BoardDto toDto(BoardEntity entity) {
        if (entity == null) return null;

        BoardDto dto = new BoardDto();
        dto.setBno(entity.getBno());
        dto.setTitle(entity.getTitle());
        dto.setContent(entity.getContent());
        dto.setWriter(entity.getWriter());
        dto.setRegDate(entity.getRegdate());
        dto.setModDate(entity.getModdate());
        return dto;
    }
}
