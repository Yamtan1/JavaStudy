package com.example.rest02.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.rest02.dto.BoardDto;
import com.example.rest02.entity.BoardEntity;
import com.example.rest02.repository.BoardRepository;


@Service
public class BoardService {
	
	@Autowired
	private BoardRepository boardRepository;
	
	//게시글 등록 업무(기능= 함수) - registBoard : 준비 - 게시글, 결과 - ?
	public BoardEntity registBoard(BoardDto boardDto){
		//DTO >> Entity변환작업
		BoardEntity entity = new BoardEntity();
		entity.setTitle(boardDto.getTitle());
		entity.setContent(boardDto.getContent());
		entity.setWriter(boardDto.getWriter());
		
		BoardEntity result = boardRepository.save(entity);
		
		return result;
	}
	public BoardEntity findBoardByBno(Integer bno) {
		BoardEntity entity = boardRepository.findByBno(bno);
		return entity;
	}
	
	//게시글 수정 업무 - updateBoard : 준비 - 수정된 게시글, 결과 - ?
	public BoardEntity updateBoard(BoardDto boardDto){
		//DTO >> Entity변환작업
		BoardEntity entity = new BoardEntity();
		entity.setBno(boardDto.getBno());
		entity.setTitle(boardDto.getTitle());
		entity.setContent(boardDto.getContent());
		entity.setWriter(boardDto.getWriter());
		
		BoardEntity result = boardRepository.save(entity);
		return result;
	}
	
	//게시글 삭제 업무 - deleteBoard : 준비 - bno, 결과 : ?
	public void deleteBoard(Integer bno) {
		boardRepository.deleteById(bno);
	}
	
}
