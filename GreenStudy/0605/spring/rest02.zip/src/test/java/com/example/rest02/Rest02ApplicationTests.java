package com.example.rest02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Rest02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
