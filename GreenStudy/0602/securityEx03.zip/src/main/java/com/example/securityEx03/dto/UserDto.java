package com.example.securityEx03.dto;

import lombok.Data;

@Data
public class UserDto {
	
	private String username;
	private String password;
	private String name;
	private String role;
}
