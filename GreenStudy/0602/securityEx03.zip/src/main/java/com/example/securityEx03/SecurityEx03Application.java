package com.example.securityEx03;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityEx03Application {

	public static void main(String[] args) {
		SpringApplication.run(SecurityEx03Application.class, args);
	}

}
