package com.example.jwtEx01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtEx01Application {

	public static void main(String[] args) {
		SpringApplication.run(JwtEx01Application.class, args);
	}

}
